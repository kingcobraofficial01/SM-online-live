# SM Online LIVE — Android Starter Project

এটি SM Online LIVE-এর প্রথম Android starter project: একটি native Android app shell (Kotlin + WebView) এবং offline HTML demo UI।

## এই সংস্করণে কাজ করে
- মোবাইল নম্বরের ১০টি সংখ্যা যাচাই করে local demo sign-in (কোনো SMS/OTP পাঠায় না)
- ৮টি account role দেখায়: CEO, Super Admin, Admin, BDM, BD, Agency, Host, Normal User
- Demo CEO/Management panel
- Sample Agency/Host registration request approve/reject (শুধু app চলাকালীন demo memory-তে)
- Home, Video Live, Audio Live, Inbox, Profile-এর placeholder screen/action
- Offline asset; demo চালাতে backend লাগে না

## এই সংস্করণে বাস্তব নয়
- OTP, real account/database, server-side role permissions
- Real video/audio streaming, chat, gifts, wallet, payments, payout
- Production moderation, block/report, notifications, user-data deletion

**এটি এখনো APK/AAB নয় এবং Play Store-এ upload-ready release নয়।** এখানে Android SDK/Gradle দিয়ে build বা device test করা হয়নি।

## Build করতে
প্রয়োজন: Android Studio, JDK 17+, Android SDK Platform 36, Android Gradle Plugin 8.13.0-compatible Gradle 8.13+।

1. ZIP extract করুন।
2. Android Studio-তে `SM_Online_LIVE_Android` folder Open করুন।
3. Gradle sync সম্পন্ন হতে দিন এবং Android SDK 36 install করুন।
4. Run দিয়ে emulator/Android device-এ demo পরীক্ষা করুন।
5. AAB-এর জন্য: **Build → Generate Signed Bundle / APK → Android App Bundle** নির্বাচন করুন।
6. নিজের release keystore তৈরি করে নিরাপদে backup রাখুন। Keystore/password কাউকে দেবেন না।

## Mobile-only ব্যবহার
এই project folder Android ফোনে extract করা যায়, কিন্তু এই পরিবেশে APK/AAB compile করার Android SDK/Gradle নেই। ফোনে build করতে হলে Android-compatible IDE/build environment এবং SDK setup লাগবে; সেটি ডিভাইস/IDE অনুযায়ী আলাদা।

## Application details
- App name: SM Online LIVE
- Application ID: `com.smonlinelive.app`
- Version: `0.1.0` (versionCode 1)
- minSdk: 24
- targetSdk / compileSdk: 36

## পরবর্তী production কাজ
1. Firebase Phone Auth বা অন্য OTP provider, abuse protection এবং privacy-safe phone verification
2. Secure backend + database; সব role permission server-side enforce করতে হবে
3. Video/audio streaming provider, room lifecycle, moderation
4. Chat, report/block, notifications, account deletion
5. Wallet/gifts/payment থাকলে Play Billing ও ভারতীয় payment/tax/legal review
6. Privacy Policy, Data Safety, content rating, app access, screenshots ও Play Console testing
