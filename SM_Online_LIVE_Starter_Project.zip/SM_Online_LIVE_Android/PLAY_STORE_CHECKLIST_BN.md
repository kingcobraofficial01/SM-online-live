# Play Store release checklist — SM Online LIVE

- [ ] App compile ও real Android device test সম্পন্ন
- [ ] Real OTP, backend, database এবং server-side permissions নিরাপদভাবে যুক্ত
- [ ] Video/audio streaming এবং moderation test
- [ ] Chat safety: block/report, abusive content handling
- [ ] Account deletion flow এবং privacy policy URL
- [ ] Data Safety form সঠিকভাবে পূরণ
- [ ] App access instructions / test account প্রস্তুত
- [ ] App icon, screenshots, feature graphic, store description
- [ ] Content rating ও target audience declaration
- [ ] Release AAB তৈরি এবং release key নিরাপদে backup
- [ ] Play Console-এর বর্তমান target API ও testing requirements যাচাই

এই checklist সম্পন্ন না হওয়া পর্যন্ত demo-কে production-ready বলে প্রকাশ করবেন না।
